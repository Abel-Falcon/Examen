package pe.edu.upeu.LP2_clase01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lp2Clase01Application {

	public static void main(String[] args) {
		SpringApplication.run(Lp2Clase01Application.class, args);
	}

}
