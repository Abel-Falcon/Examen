package pe.edu.upeu.LP2_clase01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lp2Clase01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
